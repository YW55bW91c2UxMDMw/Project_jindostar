use anyhow::Result;
use tokio::net::TcpStream;
use tokio_socks::tcp::Socks5Stream;

const PROXY_ADDR: &str = "127.0.0.1:9050";

pub async fn connect_as_client(onion_addr: &str) -> Result<TcpStream> {
    println!("[Tor] 프록시({})를 통해 연결을 시도합니다...", PROXY_ADDR);
    let stream = Socks5Stream::connect(PROXY_ADDR, (onion_addr, 80)).await?;
    println!("[Tor] {} 서버에 성공적으로 연결되었습니다!", onion_addr);
    Ok(stream.into_inner())
}