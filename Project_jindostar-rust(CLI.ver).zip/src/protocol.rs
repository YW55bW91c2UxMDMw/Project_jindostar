use serde::{Deserialize, Serialize};

// 제어 채널용 메시지들
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct OpenChannel {
    pub channel_identifier: u32,
    pub channel_type: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ChannelResult {
    pub channel_identifier: u32,
    pub opened: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum ControlPacket {
    OpenChannel(OpenChannel),
    ChannelResult(ChannelResult),
}

// 채팅 채널용 메시지들
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ChatMessage {
    pub text: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum ChatPacket {
    Message(ChatMessage),
}