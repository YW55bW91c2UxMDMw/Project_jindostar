mod tor;
mod protocol;

use anyhow::Result;
use rust_embed::RustEmbed;
use std::io::stdin;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::io::{self, AsyncBufReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::process::{Child, Command};
use crate::protocol::{ControlPacket, OpenChannel, ChannelResult, ChatMessage, ChatPacket};
use tempfile::Builder;

#[derive(RustEmbed)]
#[folder = "tor-expert-bundle/"]
struct TorBundle;

const INTERNAL_PORT: &str = "127.0.0.1:9999";

fn setup_tor_environment() -> Result<PathBuf> {
    // 시스템 임시 디렉토리에 고유한 이름의 폴더를 생성합니다.
    let temp_dir = Builder::new().prefix("jindostar").tempdir()?;
    println!("[자동화] 임시 Tor 폴더 생성: {:?}", temp_dir.path());

    for filename in TorBundle::iter() {
        let asset = TorBundle::get(filename.as_ref()).unwrap();
        let path = temp_dir.path().join(filename.as_ref());
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&path, asset.data)?;
    }
    
    println!("[자동화] Tor 환경 설정 완료.");
    // into_path()를 호출하여 프로그램 종료 시 폴더가 자동으로 삭제되도록 합니다.
    Ok(temp_dir.into_path())
}

#[tokio::main]
async fn main() -> Result<()> {
    let tor_dir = setup_tor_environment()?;
    println!("--- Jindostar Messenger (v2.2.0) ---");
    println!(" 역할을 선택하세요 (1: 서버, 2: 클라이언트):");

    let mut role = String::new();
    stdin().read_line(&mut role)?;

    let mut tor_process: Option<Child> = if role.trim() == "1" {
        Some(run_server(&tor_dir).await?)
    } else {
        Some(run_client(&tor_dir).await?)
    };

    if let Some(mut process) = tor_process.take() {
        println!("[자동화] Jindostar를 종료하며 Tor 프로세스를 함께 종료합니다.");
        process.kill().await?;
    }
    
    Ok(())
}

async fn wait_for_tor_bootstrap(process: &mut Child) -> Result<()> {
    println!("[자동화] Tor 부트스트랩을 기다립니다...");
    
    // Tor 프로세스의 표준 출력(stdout)을 가져옵니다.
    let stdout = process.stdout.take().ok_or_else(|| anyhow::anyhow!("Tor 프로세스의 표준 출력을 가져올 수 없습니다."))?;
    let mut reader = io::BufReader::new(stdout).lines();

    // 로그를 한 줄씩 읽으면서 100% 완료 메시지를 찾습니다.
    while let Some(line) = reader.next_line().await? {
        println!("[Tor 로그] {}", line); // 모든 로그를 화면에 보여줘서 진행 상황을 알 수 있게 함
        if line.contains("Bootstrapped 100% (done): Done") {
            println!("[자동화] Tor 부트스트랩 완료.");
            return Ok(());
        }
    }

    anyhow::bail!("Tor 로그 스트림이 끝났지만, 부트스트랩 완료 메시지를 찾지 못했습니다.")
}

async fn run_server(tor_dir: &Path) -> Result<Child> {
    //... torrc 생성 로직
    println!("[자동화] 서버 역할 선택됨. torrc 파일을 생성합니다.");
    let torrc_path = tor_dir.join("torrc");
    let data_dir_path = tor_dir.join("data");
    let hidden_service_path = data_dir_path.join("hidden_service");
    let torrc_content = format!(
        "DataDirectory {}\nHiddenServiceDir {}\nHiddenServicePort 80 {}",
        data_dir_path.to_string_lossy().replace('\\', "/"),
        hidden_service_path.to_string_lossy().replace('\\', "/"),
        INTERNAL_PORT
    );
    tokio::fs::write(&torrc_path, torrc_content).await?;
    println!("[자동화] torrc 파일 생성 완료.");

    let tor_exe_path = tor_dir.join("tor").join("tor.exe");
    if !tokio::fs::try_exists(&tor_exe_path).await? {
        anyhow::bail!("치명적 오류: tor.exe 파일이 없습니다!");
    }
    
    println!("[자동화] Tor 프로세스를 시작합니다.");
    let tor_process = Command::new(tor_exe_path)
        .arg("-f")
        .arg(torrc_path)
        .stdout(std::process::Stdio::piped())
        .spawn()?;
    
    wait_for_tor_bootstrap(&mut tor_process).await?;
    
    let hidden_service_path = tor_dir.join("data").join("hidden_service");
    let hostname_path = hidden_service_path.join("hostname");
    let onion_address = tokio::fs::read_to_string(hostname_path).await?;
    println!("\n==================================================");
    println!(" [서버 주소]: {}", onion_address.trim());
    println!("==================================================\n");
    println!("[서버] 클라이언트 연결을 기다립니다...");

    let listener = TcpListener::bind(INTERNAL_PORT).await?;
    let (stream, _addr) = listener.accept().await?;
    println!("[서버] 클라이언트와 연결되었습니다!");

    let (reader, mut writer) = stream.into_split();
    let mut reader = io::BufReader::new(reader);
    let mut line = String::new();
    reader.read_line(&mut line).await?;
    let packet: ControlPacket = serde_json::from_str(line.trim())?;
    
    if let ControlPacket::OpenChannel(req) = packet {
        println!("[서버] 채널 열기 요청 받음 (ID: {}, 타입: {})", req.channel_identifier, req.channel_type);

        println!("이 연결 요청을 수락하시겠습니까? (y/n)");
        let mut user_input = String::new();
        stdin().read_line(&mut user_input)?;
        let accepted = user_input.trim().eq_ignore_ascii_case("y");
        // --- 여기까지 추가 ---

        let response = ControlPacket::ChannelResult(ChannelResult {
            channel_identifier: req.channel_identifier,
            opened: accepted, // 사용자의 선택을 응답에 반영
        });
        let response_json = serde_json::to_string(&response)? + "\n";
        writer.write_all(response_json.as_bytes()).await?;
        println!("[서버] 채널 결과 응답 전송 (수락: {})", accepted);

        if accepted {
            handle_chat_session(reader, writer).await?;
        } else {
            println!("[서버] 연결 요청을 거부했습니다. 연결을 종료합니다.");
        }
    }
    
    Ok(tor_process)
}

async fn run_client(tor_dir: &Path) -> Result<Child> {
    //... torrc 생성 로직
    println!("[자동화] 클라이언트 역할 선택됨. 프록시용 torrc를 생성합니다.");
    let torrc_client_path = tor_dir.join("torrc-client");
    let data_dir_path = tor_dir.join("data-client");
    let torrc_content = format!(
        "SocksPort 9050\nDataDirectory {}",
        data_dir_path.to_string_lossy().replace('\\', "/")
    );
    tokio::fs::write(&torrc_client_path, torrc_content).await?;
    println!("[자동화] torrc-client 파일 생성 완료.");

    let tor_exe_path = tor_dir.join("tor").join("tor.exe");
    if !tokio::fs::try_exists(&tor_exe_path).await? {
        anyhow::bail!("치명적 오류: tor.exe 파일이 없습니다!");
    }
    
    println!("[자동화] 클라이언트용 Tor 프록시 프로세스를 시작합니다...");
    let tor_process = Command::new(&tor_exe_path)
        .arg("-f")
        .arg(&torrc_client_path)
        .stdout(std::process::Stdio::piped())
        .spawn()?;
    
    wait_for_tor_bootstrap(&mut tor_process).await?;

    println!(" 접속할 상대방의 .onion 주소를 입력하세요:");
    let mut onion_addr = String::new();
    stdin().read_line(&mut onion_addr)?;
    let onion_addr = onion_addr.trim();
    
    let stream = tor::connect_as_client(onion_addr).await?;
    
    let (reader, mut writer) = stream.into_split();
    let mut reader = io::BufReader::new(reader);

    let request = ControlPacket::OpenChannel(OpenChannel {
        channel_identifier: 1,
        channel_type: "im.ricochet.chat".to_string(),
    });
    let request_json = serde_json::to_string(&request)? + "\n";
    writer.write_all(request_json.as_bytes()).await?;
    println!("[클라이언트] 채널 열기 요청 전송");

    let mut line = String::new();
    reader.read_line(&mut line).await?;
    let response: ControlPacket = serde_json::from_str(line.trim())?;
    
    if let ControlPacket::ChannelResult(res) = response {
        println!("[클라이언트] 채널 결과 응답 받음 (ID: {}, 성공: {})", res.channel_identifier, res.opened);
        if res.opened {
            
            handle_chat_session(reader, writer).await?;
            } else {
            // 거부되었을 때 메시지 출력
            println!("[클라이언트] 서버로부터 연결이 거부되었습니다.");
        }
    }

    Ok(tor_process)
}

async fn handle_chat_session(
    mut reader: io::BufReader<tokio::net::tcp::OwnedReadHalf>,
    mut writer: tokio::net::tcp::OwnedWriteHalf,
) -> Result<()> {
    println!("--- 채팅 채널 활성화. ---");

    let mut stdin = io::BufReader::new(io::stdin());
    
    loop {
        let mut net_line = String::new();
        let mut stdin_line = String::new();
        tokio::select! {
            result = reader.read_line(&mut net_line) => {
                match result {
                    Ok(0) | Err(_) => {
                        println!("\n[상대방과의 연결이 끊어졌습니다.]");
                        break;
                    },
                    Ok(_) => {
                        let packet: ChatPacket = serde_json::from_str(net_line.trim())?;
                        if let ChatPacket::Message(msg) = packet {
                            println!("\n상대방: {}", msg.text);
                        }
                        net_line.clear();
                    }
                }
            },
            result = stdin.read_line(&mut stdin_line) => {
                match result {
                    Ok(_) => {
                        let message_text = stdin_line.trim();
                        if message_text == "exit" {
                            println!("[연결을 종료합니다.]");
                            break;
                        }
                        
                        let packet = ChatPacket::Message(ChatMessage { text: message_text.to_string() });
                        let packet_json = serde_json::to_string(&packet)? + "\n";
                        if writer.write_all(packet_json.as_bytes()).await.is_err() {
                            eprintln!("[메시지 전송에 실패했습니다.]");
                            break;
                        }
                        println!("나: {}", message_text);
                        stdin_line.clear();
                    },
                    Err(_) => {
                        println!("\n[입력 오류가 발생했습니다.]");
                        break;
                    }
                }
            }
        }
    }
    Ok(())
}