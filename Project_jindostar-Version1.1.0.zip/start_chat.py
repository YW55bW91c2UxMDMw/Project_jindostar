# final_chat.py (최종 자동화 완성판)
import os
import sys
import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog, messagebox
import socks
import subprocess
import atexit
import queue

# --- 전역 변수 및 경로 설정 ---
tor_process = None
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

TOR_BUNDLE_DIR = os.path.join(BASE_DIR, "tor-expert-bundle")
TOR_DIR = os.path.join(TOR_BUNDLE_DIR, "Tor")
TOR_EXE_PATH = os.path.join(TOR_DIR, "tor.exe")
TOR_DATA_DIR = os.path.join(TOR_BUNDLE_DIR, "Data")
HIDDEN_SERVICE_DIR = os.path.join(TOR_DATA_DIR, "Tor", "hidden_service")
HOSTNAME_PATH = os.path.join(HIDDEN_SERVICE_DIR, "hostname")
TORRC_PATH = os.path.join(TOR_DIR, "torrc")

def cleanup_tor_process():
    global tor_process
    if tor_process and tor_process.poll() is None:
        print("Tor 프로세스를 종료합니다...")
        tor_process.terminate()
        tor_process.wait()
        print("Tor 프로세스가 종료되었습니다.")
atexit.register(cleanup_tor_process)

def receive_messages(sock, text_area):
    while True:
        try:
            data = sock.recv(1024)
            if not data:
                text_area.insert(tk.END, "\n[상대방과의 연결이 끊겼습니다.]")
                break
            text_area.insert(tk.END, f"\n상대방: {data.decode()}")
            text_area.see(tk.END)
        except:
            break

def send_message(sock, entry, text_area):
    message = entry.get()
    if message:
        text_area.insert(tk.END, f"\n나: {message}")
        text_area.see(tk.END)
        try:
            sock.sendall(message.encode())
            entry.delete(0, tk.END)
        except:
            text_area.insert(tk.END, "\n[메시지 전송에 실패했습니다.]")

class ChatApplication:
    def __init__(self, root):
        self.root = root
        self.connection_socket = None
        self.my_onion_address = ""
        self.log_queue = queue.Queue()
        self.setup_successful = False
        
        self.setup_initial_ui()
        self.root.after(100, self.start_tor_setup)

    def setup_initial_ui(self):
        self.root.title("Project Jindostar - 초기화 중...")
        self.status_label = tk.Label(self.root, text="Tor 설정을 시작합니다...", padx=20, pady=20)
        self.status_label.pack()

    def read_tor_logs(self):
        # universal_newlines=True는 출력을 텍스트로 다루게 함
        for line in iter(tor_process.stdout.readline, ''):
            self.log_queue.put(line)
        tor_process.stdout.close()

    def start_tor_setup(self):
        global tor_process
        if not os.path.exists(TORRC_PATH):
            if not os.path.exists(HIDDEN_SERVICE_DIR): os.makedirs(HIDDEN_SERVICE_DIR)
            torrc_content = (
                f"HiddenServiceDir \"{HIDDEN_SERVICE_DIR.replace('\\', '/')}\"\n"
                f"HiddenServicePort 9999 127.0.0.1:9999\n"
                f"DataDirectory \"{os.path.join(TOR_DATA_DIR, 'Tor').replace('\\', '/')}\""
            )
            with open(TORRC_PATH, 'w') as f: f.write(torrc_content)

        creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        tor_process = subprocess.Popen(
            [TOR_EXE_PATH, "-f", TORRC_PATH],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            universal_newlines=True, creationflags=creation_flags
        )
        
        log_thread = threading.Thread(target=self.read_tor_logs, daemon=True)
        log_thread.start()

        self.check_tor_status()

    def check_tor_status(self):
        try:
            while not self.log_queue.empty():
                line = self.log_queue.get_nowait()
                print(f"Tor Log: {line.strip()}")
                if "Bootstrapped 100%" in line:
                    self.status_label.config(text="Tor 네트워크 연결 완료! 주소를 확인합니다...")
                    self.get_hostname_and_finish()
                    return
                elif "Bootstrapped" in line:
                    percentage = line.split('Bootstrapped ')[1].split('%')[0]
                    self.status_label.config(text=f"Tor 네트워크 연결 진행률: {percentage}%")
        except queue.Empty:
            pass
        
        self.root.after(200, self.check_tor_status)

    def get_hostname_and_finish(self):
        try:
            with open(HOSTNAME_PATH, 'r') as f:
                self.my_onion_address = f.read().strip()
            self.launch_main_chat_ui()
        except FileNotFoundError:
            messagebox.showerror("오류", "Tor는 연결되었으나 hostname 파일을 찾을 수 없습니다.")
            self.root.destroy()

    def launch_main_chat_ui(self):
        # 모든 설정이 끝났으므로, 이제 메인 UI를 그림
        self.status_label.destroy()
        
        # (이하 코드는 stable_chat.py와 거의 동일)
        try:
            socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
            socket.socket = socks.socksocket
        except Exception as e:
            messagebox.showerror("오류", f"Tor 프록시 연결에 실패했습니다: {e}")
            self.root.destroy()
            return

        # (이하 UI 및 네트워크 스레드 시작 코드)
        self.root.title("Project Jindostar")
        address_frame = tk.Frame(self.root)
        address_frame.pack(padx=10, pady=5, fill=tk.X)
        tk.Label(address_frame, text="나의 주소:").pack(side=tk.LEFT)
        self.address_entry = tk.Entry(address_frame)
        self.address_entry.insert(0, self.my_onion_address)
        self.address_entry.config(state='readonly')
        self.address_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.chat_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD)
        self.chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        input_frame = tk.Frame(self.root)
        input_frame.pack(padx=10, pady=10, fill=tk.X)
        self.entry_field = tk.Entry(input_frame)
        self.entry_field.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.send_button = tk.Button(input_frame, text="전송", command=self.send)
        self.send_button.pack(side=tk.RIGHT)
        self.root.bind('<Return>', self.send)

        self.role = messagebox.askquestion("역할 선택", "서버(대화방 개설)로 실행하시겠습니까?")
        if self.role == 'no':
            self.server_address = simpledialog.askstring("Onion 주소", "접속할 상대방의 .onion 주소를 입력하세요:")
            if not self.server_address:
                self.root.destroy()
                return
        
        self.setup_successful = True
        self.start_network_thread()

    def send(self, event=None):
        if self.connection_socket:
            send_message(self.connection_socket, self.entry_field, self.chat_area)
        else:
            self.chat_area.insert(tk.END, "\n[아직 연결되지 않았습니다.]")

    def start_network_thread(self):
        network_thread = threading.Thread(target=self.network_logic, daemon=True)
        network_thread.start()

    def network_logic(self):
        # (이하 network_logic 코드는 stable_chat.py와 동일)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if self.role == 'yes':
            try:
                sock.bind(('127.0.0.1', 9999))
                sock.listen()
                self.chat_area.insert(tk.END, f"\n[{self.my_onion_address}] 주소로 연결을 기다리는 중...")
                conn, addr = sock.accept()
                self.chat_area.insert(tk.END, "\n[연결되었습니다.]")
                self.connection_socket = conn
            except Exception as e:
                self.chat_area.insert(tk.END, f"\n[서버 실행 실패: {e}]")
                return
        else:
            try:
                sock.connect((self.server_address, 9999))
                self.chat_area.insert(tk.END, "\n[서버에 연결되었습니다.]")
                self.connection_socket = sock
            except Exception as e:
                self.chat_area.insert(tk.END, f"\n[연결 실패: {e}]")
                return
        receive_thread = threading.Thread(target=receive_messages, args=(self.connection_socket, self.chat_area), daemon=True)
        receive_thread.start()

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApplication(root)
    root.mainloop()